#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

#include "arvore.h"

struct arvno {
  int info;
  ArvNo* esq;
  ArvNo* dir;
};

ArvNo* cria_no (int v, ArvNo* esq, ArvNo* dir)
{
  ArvNo* p = (ArvNo*)malloc(sizeof(ArvNo));
  if (p != NULL) {
    p->info = v;
    p->esq = esq;
    p->dir = dir;
  }
  return p;
}

void imprime (ArvNo* r)
{
  printf("(");
  if (r != NULL) {
    printf("%d ", r->info);
    imprime(r->esq);
    printf(", ");
    imprime(r->dir);
  }
  printf(")");
}

void libera (ArvNo* r)
{
  if (r != NULL) {
    libera(r->esq);
    libera(r->dir);
    free(r);
  }
}

int num_nos (ArvNo* r)
{
  // COMPLETAR
  return -1;
}

static int e_abb_preordem (ArvNo* r, int min, int max)
{
  // COMPLETAR: Escolha entre completar 'e_abb_preordem' OU 'e_abb_simetrica'
  return 0;
}

static int e_abb_simetrica (ArvNo *r, int *corrente)
 {
  // COMPLETAR: Escolha entre completar 'e_abb_preordem' OU 'e_abb_simetrica'
  return 0;
}

int e_abb (ArvNo* r)
{
# if 1 // Troque para 0 se optar por implementar a função e_abb_preordem
  int corrente = INT_MIN;
  return e_abb_simetrica(r, &corrente);
#else
  return e_abb_preordem(r, INT_MIN, INT_MAX);
#endif
}

int arvores_iguais (ArvNo* r1, ArvNo* r2)
{
  // COMPLETAR
  return 0;
}

int num_maiores_que (ArvNo* r, int v)
{
  int nos = 0;
  // COMPLETAR
  return nos;
}

ArvNo* insere (ArvNo* r, int v)
{
  if (r == NULL)
    return cria_no(v, NULL, NULL);
  else if (v < r->info)
    r->esq = insere(r->esq, v);
  else // v > r->info
    r->dir = insere(r->dir, v);
  return r;  
}
