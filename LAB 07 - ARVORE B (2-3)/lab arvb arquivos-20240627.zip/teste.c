#include <stdio.h>
#include "arvb23.h"

int main (void) {
  ArvB23 *b = cria();
  int chave;
  
  while (1) {
    printf ("chave a inserir (-111 para terminar): ");
    scanf ("%d", &chave);
    if (chave==-111) break;

    b = insere(b, chave);
    printf("arvore: \n");
    mostra(b);
  }
  destroi(b); 
  return 0;
}    
